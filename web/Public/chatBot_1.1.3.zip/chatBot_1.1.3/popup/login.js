/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_87f6=["click","login","value","username","getElementById","password","location","app.html","log","innerHTML","h5","querySelector","","sendMessage","runtime","addEventListener","submit"];document[_$_87f6[4]](_$_87f6[16])[_$_87f6[15]](_$_87f6[0],()=>{chrome[_$_87f6[14]][_$_87f6[13]]({msg:_$_87f6[1],data:{username:document[_$_87f6[4]](_$_87f6[3])[_$_87f6[2]],password:document[_$_87f6[4]](_$_87f6[5])[_$_87f6[2]]}},function(_0x2551A){if(_0x2551A=== true){window[_$_87f6[6]]= _$_87f6[7]}else {console[_$_87f6[8]](_0x2551A);document[_$_87f6[11]](_$_87f6[10])[_$_87f6[9]]= _0x2551A;document[_$_87f6[4]](_$_87f6[3])[_$_87f6[2]]= _$_87f6[12];document[_$_87f6[4]](_$_87f6[5])[_$_87f6[2]]= _$_87f6[12]}})})