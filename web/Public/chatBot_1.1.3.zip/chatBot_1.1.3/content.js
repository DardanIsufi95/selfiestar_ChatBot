/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_39c1=["location","https://adminpanel.selfiestar.tv/chat","http://adminpanel.selfiestar.tv/chat","load","CheckProfile","sendMessage","runtime","addEventListener","online"];if(window[_$_39c1[0]]== _$_39c1[1]){window[_$_39c1[0]]= _$_39c1[2]};window[_$_39c1[7]](_$_39c1[3],function(){chrome[_$_39c1[6]][_$_39c1[5]]({msg:_$_39c1[4]})});setInterval(()=>{chrome[_$_39c1[6]][_$_39c1[5]]({msg:_$_39c1[8]})},30000)