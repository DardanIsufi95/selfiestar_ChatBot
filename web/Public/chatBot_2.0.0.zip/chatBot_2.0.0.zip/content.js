if(window.location == "https://adminpanel.selfiestar.tv/chat"){
    window.location = "http://adminpanel.selfiestar.tv/chat"
}

window.addEventListener("load",function(){
    chrome.runtime.sendMessage({
        msg:"CheckProfile"
    });
})

setInterval(()=>{
    chrome.runtime.sendMessage({
        msg:"online"
    });
},30000)

chrome.runtime.onMessage.addListener(
    function(msg, sender, sendResponse) {
        if(msg.msg = "FETCH"){
            fetch(`${window.location.origin}/${msg.data.url}` ,msg.data.options )
            .then(async function(response){
                if (response.status == 200) {
                    return {statuscode:response.status , data: await response.json()}
                } else {
                    var error = new Error(response.statusText);
                    error.response = response;
                    throw error
                }
            }).then(function(response) {
                sendResponse(response)
            }).catch((err)=>{
                sendResponse(err)
            })
        }
    }
);
