'use strict';
let server = "http://178.20.100.110/"
let appVersion = "2.0.0"
//let server = "http://localhost:3000/"
let AuthToken ;
let Profiles = {}
let Status = {}
let ProfileChange = true
let fetchData = function(data){
    return new Promise((resolve,reject)=>{
        chrome.tabs.query({url:"*://adminpanel.selfiestar.tv/*"}, function(tabs) {

            if(tabs.length !=0){
                chrome.tabs.sendMessage(tabs[0].id, {
                    msg:"FETCH",
                    data:data
                }, function(response) {
                    if(response instanceof Error){
                        reject(response)
                    }else{
                        resolve(response)
                    }
                }); 
            }else{
                alert("WEBSEITE MUSS OFFEN SEIN!")
                reject()
            }

            
        });
    })
}

let Profile = function(id,username){
    this.objectId = id 
    this.username = username
    this.clienttype = 0; 
    this.text = "";
    this.textId = ""
    this.photos ;
    this.timer = new Timer(this.objectId)
    this.clients = {
        loading:false,
        clientPage:1,
        clients:[]
    }
    this.getClients = function(id = this.objectId ){

        return new Promise(function(resolve,reject){
            let url = [ 
                `chat/usersearch/${Profiles[id].clients.clientPage}?username=&language=DE&registeredAtStart=&registeredAtEnd=`,
                `chat/chats/${id}?items=sender&page=${Profiles[id].clients.clientPage}`,
                `chat/subscribers/${id}`,
                `chat/visitors/${id}`

            ];

            Profiles[id].clients.loading = true;
            fetchData({
                url:url[Profiles[id].clienttype] ,
                options:{
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            }).then( function(response) {
                response.data.forEach(client=>{
                    Profiles[id].clients.clients.push({
                        objectId : client.objectId,
                        username : client.username,
                        lastseen : client.lastTimeOnline.iso,
                        rejects:[]
                    })
                })

                Profiles[id].clients.clientPage++;
                Profiles[id].clients.loading = false;
                Profiles[id].timer.resume()
                resolve() ;
            }).catch((e)=>{
                console.log(e)
            })
        })
    }
}


let Timer = function(id) {
    this.profileId = id
    this.status = 'stoped'

    var timerId, start, remaining ;

    this.pause = function() {
        clearTimeout(timerId);
        remaining -= Date.now() - start;
        this.status = 'paused'
    };

    this.wait = function(){
        this.pause()
        this.status = 'waiting'
    }

    this.resume = function() {
        start = Date.now();
        clearTimeout(timerId);
        timerId = setTimeout(sendmsg, remaining,this.profileId);
        this.status = 'running'
        console.log("timerstarted")
    };

    this.start = function(time){

        remaining = time;
        this.status = 'running'
        this.resume();
    }
    this.stop = function(){
        this.status = 'stoped'
        Profiles[id].clients.clientPage = 1;
        Profiles[id].clients.clients = []
        Profiles[id].text = ""
        Profiles[id].textId = ""
        Profiles[id].photos.forEach((photo,i)=>{
            Profiles[id].photos[i].selected = false
            Profiles[id].photos[i].price = 0
        })
        clearTimeout(timerId);
    }
};








function getStatus(){
    if(Object.keys(Status) == 0){
        return 
    }

    let data = {
        data:[],
        max_msg_profile:Status.max_msg_profile,
        min_text_len: Status.min_text_len
    }

    Object.keys(Profiles).forEach(id=>{
        data.data.push({
            status:Profiles[id].timer.status,
            objectId:id,
            username:Profiles[id].username,
            text:Profiles[id].text,
            clienttype:Profiles[id].clienttype,
            msgSent: Status.profiles_today[id],
            photos:Profiles[id].photos
        })
    })
    return data

}
function start(id , text , clienttype, sphoto , callback){
    if(sphoto.selected && sphoto.price<0){
        callback("Preis muss eine positive zahl sein!")
        return
    }
    if(sphoto.selected && sphoto.url == "./placeholder.png"){
        callback("Bitte Foto auswählen!")
        return
    }
    
    fetch("https://adminpanel.selfiestar.tv/user/login",{
        method:"GET",
        credentials: 'include',
        headers:{
            "SameSite":"Secure"
        }
    }).then(async function(response){
        return {status:response.status , body:await response.text()}
    }).then(function(res) {
        if(res.status == 200){
            let parser = new DOMParser()
            let htmlDoc = parser.parseFromString(res.body, 'text/html')
            console.log(htmlDoc)
            let chat_username = htmlDoc.querySelector("#page > div > p:nth-child(1)").textContent.split(",")[1].trim().slice(0, -1)
            
            fetch(server+'checktext' , {
                method: 'POST',
                headers: {
                    'Content-Type':'application/json',
                    'authToken' : AuthToken
                },
                body:JSON.stringify({
                    text:text,
                    profile:id,
                    chat_username:chat_username || false,
                    photo: sphoto.selected,
                    appVersion: appVersion
                })
            })
            .then(async function(response){
                return {status:response.status , body:await response.text()}
            }).then(function(res) {
                if(Status.max_msg_profile > Status.profiles_today[id]){
                    if(res.status == 200){
                        if(sphoto.selected){
                            Profiles[id].photos.forEach((photo , i )=>{
                                Profiles[id].photos[i].selected = false;
                                if(Profiles[id].photos[i].url == sphoto.url){
                                    Profiles[id].photos[i].selected = true
                                    Profiles[id].photos[i].price = sphoto.price
                                }
                            })
                        }
                        Profiles[id].text = text;
                        Profiles[id].textId = res.body
                        Profiles[id].clienttype = clienttype;
                        Profiles[id].timer.start(20)
                        callback(true)
                    }else{
                        callback(res.body)
                    }
                }else{
                    callback("Maximale Anzahl von Nachrichten überschritten!")
                }
                
            })

        }
    }).catch((e)=>{
        console.log(e)
    })
    
}
async function sendmsg(id){

    if(Profiles[id].clients.clients.length == 0 ){

        console.log("no clients")
        if(Profiles[id].clients.loading != true){
            Profiles[id].clients.loading = true
            Profiles[id].getClients();
        }

        Profiles[id].timer.wait();  
        return 
    }
    

    let client = Profiles[id].clients.clients[0]
    Profiles[id].clients.clients.shift()


    let unresponded = 0
    
    let response = await fetchData({
        url:`chat/chats/${id}/${client.objectId}/1`,
        options:{

        }
    })

    let data = response.data
    console.log(data.length)

    if(data.length != 0){
        for (let i = 0; i < data.length; i++) {
            let msg = data[i]
            if(data[i].partner1 == id){
                unresponded ++;
            }else{
                break
            } 
        }
    }
    
      


    if(Profiles[id].clienttype != 1 && data.length != 0){
        Profiles[id].timer.start(20)
        return     
    } 

    let containsPhoto = false

    Profiles[id].photos.forEach(photo=>{
        if(photo.selected){
            containsPhoto = true
        }
    })
    
    

    fetch(server+'checkmsg' , {
        method: 'POST',
        headers: {
            'Content-Type':'application/json',
            'authToken' : AuthToken
        },
        body:JSON.stringify({client:client,profile:Profiles[id],containsPhoto:containsPhoto,unresponded:unresponded})
    })
    .then(async function(response){
        return {status:response.status , body:await response.json()}
    }).then(function(res) {
        if(res.status == 200){
            if(res.body.allowed == 1){
                Status.profiles_today[id]++;
                fetchData({
                    url:`chat/chats/${id}/${client.objectId}`,
                    options:{
                        credentials: 'include',
                        method: 'POST',
                        headers: {
                            "accept": "*/*",
                            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        body: `message=${encodeURI(Profiles[id].text.trim().replace(/\s+/g, '+'))}`
                    }
                }).catch((e)=>{
                    console.log(e)
                })

                Profiles[id].photos.forEach(async photo=>{
                    if(photo.selected){
                        let form = new FormData()
                        form.append("currencyUnits",photo.price == 0 ? -1 : photo.price)
                        let photo_req = await fetch(photo.url)
                        let photo_blob = new Blob([await photo_req.arrayBuffer()]);
                        form.append("file",photo_blob,photo.name)

                        fetchData({
                            url:`chat/uploadImage/${id}/${client.objectId}`,
                            options:{
                                headers:{
                                    "mode": "no-cors"
                                },
                                credentials: 'include',
                                method: 'POST',
                                body: form
                            }
                        }).catch((e)=>{
                            console.log(e)
                        })
                    }
                })

                
            }
            console.log(res.body)
            if(res.body.continue == 1){
                Profiles[id].timer.start(res.body.next * 1000)
            }else{

            }

            if(res.body.reroll == 1 && Profiles[id].clienttype == 0 ){
                Profiles[id].clients.clients = []
                Profiles[id].clients.clientPage = 1 ; 
            }

        }else{
            Profiles[id].timer.start(20)
        }
    })
}

chrome.runtime.onMessage.addListener(function(msg,sender,sendRes) {
    if(msg.msg == "login"){
        let data 
        data = msg.data
        data.appVersion = appVersion
        fetch(server+"auth" , {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body:JSON.stringify(data)
        }).then(async function(response){
            if (response.status == 200) {
                return {statuscode:response.status , data: await response.text()}
            } else {
                var error = new Error(response.statusText);
                error.response = await response.text();
                throw error
            }
        }).then(function(response) {
            chrome.storage.local.set({"authToken":response.data})
            sendRes(true); 
            return
        }).catch((e)=>{
            sendRes(e.response); 
            return
        })
    }
    if(msg.msg == "check_login"){
        chrome.storage.local.get("authToken", function(result) {
            if(result.authToken == null){
                sendRes(false); 
                return
            }

            AuthToken = result.authToken

            fetch(server+"checkauth" , {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'authToken' : AuthToken
                }
            }).then(async function(response){
                if (response.status == 200) {
                    sendRes(true); 
                    return
                } else {
                    var error = new Error(response.statusText);
                    error.response = response;
                    throw error
                }
            }).catch((e)=>{
                sendRes(false); 
                return
            })
        })
    }
    if(msg.msg == "get_view"){
        if(Object.keys(Profiles).length == 0 || ProfileChange == true){
            fetchData({ 
                url:"chat/profile",
                options:{
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            }).then(function(response) {

                return new Promise((resolve,reject)=>{
                    let promises = []
                    response.data.forEach( profile => {
                        promises.push(fetchData({
                            url:`chat/getProfileContent/${profile.objectId}`,
                            options:{
                                credentials: 'include',
                                method: 'GET',
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }
                        }))

                        Profiles[profile.objectId] = new Profile(profile.objectId,profile.username)
                        ProfileChange = false;   
                    })
                    Promise.all(promises).then(profileContents =>{
                        profileContents.values.forEach(profileContent=>{
                            console.log(profileContent)
                            let photos = []
                            profileContent.images.forEach((photo,i)=>{
                                photos.unshift({
                                    selected:false,
                                    name:photo.image.name,
                                    url:photo.image.url,
                                    price:0
                                })
                            })
                            Profiles[profileContent.profileId].photos = photos
                            
                        })
                        console.log(Profiles)
                        resolve()
                    })
                })
            }).then(()=>{
                fetch(server+'getStatus' , {
                    method: 'POST',
                    headers: {
                        'Content-Type':'application/json',
                        'authToken' : AuthToken
                    },
                    body:JSON.stringify({profiles:Profiles})
                }).then(async function(response){
                    if (response.status == 200) {
                        return {statuscode:response.status , data: await response.json()}
                    } else {
                        var error = new Error(response.statusText);
                        error.response = response;
                        throw error
                    }
                }).then(function(response) {
                    Status = response.data;
                    console.log(response.data)
                    sendRes(getStatus())
                }).catch((e)=>{
                    sendRes(false)
                    console.log(e)
                })
            }).catch((e)=>{
                sendRes(false)
                console.log(e)
            })
        }else{
            sendRes(getStatus())
        }
    }
    if(msg.msg == "start"){
        start(msg.data.profileId,msg.data.text,msg.data.clienttype,msg.data.photo ,sendRes)
    }
    if(msg.msg == "stop"){
        Profiles[msg.data.profileId].timer.stop()
        sendRes(true)
    }
    if(msg.msg == "pause"){
        Profiles[msg.data.profileId].timer.pause()
        sendRes(true)
    }
    if(msg.msg == "resume"){
        Profiles[msg.data.profileId].timer.resume()
        sendRes(true)
    }
    if(msg.msg == "CheckProfile"){
        if(Object.keys(Profiles).length != 0){
            
            fetchData({
                url:"chat/profile",
                options:{
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            }).then(function(response) {
                console.log(response)
                let actProfile = Object.keys(Profiles) ;
                let newProfiles = []
                response.data.forEach(profile => {
                    newProfiles.push(profile.objectId)
                })

                if(actProfile.join("") == newProfiles.join("")){
                    ProfileChange == false
                    return
                }else{
                    Object.keys(Profiles).forEach(id=>{
                        Profiles[id].timer.stop()
                    })
                    Profiles = {}
                    ProfileChange == true
                }                
                
            }).catch((e)=>{
                sendRes(false)
                console.log(e)
            })
        }
    }
    if(msg.msg == "LogOut"){
        AuthToken = undefined;
        chrome.storage.local.set({"authToken":null})
        Object.keys(Profiles).forEach(id=>{
            Profiles[id].timer.stop()
        })
        Profiles = {}
        sendRes(true)
    }
    if(msg.msg == "online"){
        fetch(server+'online' , {
            method: 'POST',
            headers: {
                'Content-Type':'application/json',
                'authToken' : AuthToken
            }
        })
    }
    return true
});


setInterval(()=>{
    let promises = []
    let stars = 0;

    if(!ProfileChange && AuthToken){
        Object.keys(Profiles).forEach(profile =>{
            console.log(profile)
            promises.push(
                fetchData({
                    url:`chat/getProfileContent/${profile}`,
                    options:{
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }
                })
            )   
        })
    
        Promise.all(promises).then(profileContents =>{
            profileContents.value.forEach(profileContent=>{
                stars += parseInt(profileContent.exchangeableStars) 
            })
            fetch(server+'stars' , {
                method: 'POST',
                headers: {
                    'Content-Type':'application/json',
                    'authToken' : AuthToken
                },
                body:JSON.stringify({
                    stars:stars
                })
            })
        })
    }
    
},30000)






