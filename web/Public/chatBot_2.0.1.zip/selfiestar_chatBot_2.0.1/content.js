if(window.location == "https://adminpanel.selfiestar.tv/chat"){
    window.location = "http://adminpanel.selfiestar.tv/chat"
}

window.addEventListener("load",function(){
    chrome.runtime.sendMessage({
        msg:"CheckProfile"
    });
})

setInterval(()=>{
    chrome.runtime.sendMessage({
        msg:"online"
    });
},30000)

