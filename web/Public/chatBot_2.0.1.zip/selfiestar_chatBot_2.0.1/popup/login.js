
document.getElementById("submit").addEventListener("click",()=>{
    chrome.runtime.sendMessage(
        {
            msg:"login",
            data:{
                username:document.getElementById("username").value,
                password:document.getElementById("password").value
            }
        },
        function(result) {
            if(result === true){
                window.location = "app.html"
            }else{
                console.log(result)
                document.querySelector("h5").innerHTML = result
                document.getElementById("username").value = ""
                document.getElementById("password").value = ""
            }
        }
    );
})


