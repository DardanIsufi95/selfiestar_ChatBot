chrome.runtime.sendMessage(
    {
        msg:"check_login"
    },
    function(result) {
        if(!result){
            window.location = "login.html"
        }
        init()
    }
);



function init(){
    chrome.runtime.sendMessage(
        {
            msg:"get_view"
        },
        function(result) {
            console.log(result)
            if(!result){
                setTimeout(init , 500)
                return
            }
            document.getElementById("log_out_button").addEventListener("click",(e)=>{
                chrome.runtime.sendMessage(
                    {
                        msg:"LogOut"
                    },
                    function(result) {
                        window.location = "login.html"
                    }
                )
            })
            result.data.forEach(profile => {
                let tab = document.getElementById("tab_model").cloneNode({deep:true})
                tab.setAttribute('profileId',profile.objectId)
                tab.removeAttribute("style")
                tab.removeAttribute("id")
                
                tab.querySelector("a").setAttribute('href',`#profile_${profile.objectId}`)
                document.querySelector("#myTab").append(tab)



                let tabContent = document.getElementById("tab_content_model").cloneNode({deep:true})
                tabContent.removeAttribute("style")
                tabContent.setAttribute("status",profile.status)
                tabContent.setAttribute('id',`profile_${profile.objectId}`)
                tabContent.querySelector("select").value = profile.clienttype
                tabContent.querySelector("textarea").value = profile.text
                tabContent.querySelector(".msg-max").innerHTML = result.max_msg_profile 
                tabContent.querySelector(".msg-today").innerHTML = profile.msgSent
                tabContent.querySelector(".text-len").innerHTML = profile.text.length+"/"+result.min_text_len
                tabContent.querySelector("textarea").addEventListener("keyup", (e )=>{
                    e.target.value = e.target.value.replace(/\s+/g,' ')
                    document.querySelector(`.text-len[profileId='${profile.objectId}']`).innerHTML = e.target.value.length+"/"+result.min_text_len
                    if(e.target.value.length >= result.min_text_len ){
                        document.querySelector(`[profileId='${profile.objectId}'][class*='button-start']`).disabled = false
                    }else{
                        document.querySelector(`[profileId='${profile.objectId}'][class*='button-start']`).disabled = true
                    }
                })
                tabContent.querySelectorAll("[profileId='']").forEach(e=>{
                    e.setAttribute('profileId',profile.objectId)
                })
                tabContent.querySelector(`[profileId='${profile.objectId}'][class*='button-start']`).addEventListener("click", (e )=>{
                    chrome.runtime.sendMessage(
                        {
                            msg:"start",
                            data:{
                                profileId: e.target.getAttribute("profileId"),
                                text: document.querySelector(`textarea[profileId='${profile.objectId}']`).value,
                                clienttype: document.querySelector(`select[profileId='${profile.objectId}']`).value,
                                photo:{
                                    selected : document.querySelector(`#photo_checkbox_${profile.objectId}`).checked ? true : false,
                                    url: document.querySelector(`img[profileId='${profile.objectId}']`).getAttribute("src"),
                                    price: document.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).value
                                }
                            }
                        },
                        function(result) {
                            if(result == true){
                                e.target.disabled = true;
                                document.querySelector(`[href *='#profile_${profile.objectId}']`).innerHTML = profile.username + `<img width="9px" src="running.svg" alt="">`
                                document.querySelector(`[profileId='${profile.objectId}'][class*='button-pause']`).disabled = false
                                document.querySelector(`[profileId='${profile.objectId}'][class*='button-stop']`).disabled = false
                                document.querySelector(`select[profileId='${profile.objectId}']`).disabled = true
                                document.querySelector(`textarea[profileId='${profile.objectId}']`).disabled = true
                                document.querySelector(`#photo_checkbox_${profile.objectId}`).disabled = true
                                document.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).disabled = true
                                document.querySelector(`[profileId='${profile.objectId}'][class*='modal-button']`).disabled = true
                                
                            }else{
                                alert(result)
                            }                 
                            
                        }
                    );
                    
                        
                })
                tabContent.querySelector(`[profileId='${profile.objectId}'][class*='button-stop']`).addEventListener("click", (e )=>{
                    if(profile.status !="paused")
                    chrome.runtime.sendMessage(
                        {
                            msg:"stop",
                            data:{
                                profileId: e.target.getAttribute("profileId")
                            }
                        },
                        function(result) {
                            if(!result){
                                return
                            }
                            e.target.disabled = true;
                            document.querySelector(`[href *='#profile_${profile.objectId}']`).innerHTML = profile.username + `<img width="9px" src="stoped.svg" alt="">`
                            document.querySelector(`textarea[profileId='${profile.objectId}']`).value = ""
                            document.querySelector(`[profileId='${profile.objectId}'][class*='button-pause']`).disabled = true
                            document.querySelector(`[profileId='${profile.objectId}'][class*='button-start']`).disabled = false
                            document.querySelector(`select[profileId='${profile.objectId}']`).disabled = false
                            document.querySelector(`textarea[profileId='${profile.objectId}']`).disabled = false
                            document.querySelector(`#photo_checkbox_${profile.objectId}`).disabled = false
                            document.querySelector(`#photo_checkbox_${profile.objectId}`).checked = false
                            document.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).disabled = false
                            document.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).value = 0
                            document.querySelector(`[profileId='${profile.objectId}'][class*='modal-button']`).disabled = false
                        }
                    );
                })

                
                


                ///////////
                
                tabContent.querySelector("#photo_checkbox_model").setAttribute('id',`photo_checkbox_${profile.objectId}`)
                tabContent.querySelector(`#photo_checkbox_${profile.objectId}`).parentElement.querySelector("label").setAttribute('for',`photo_checkbox_${profile.objectId}`)
               

                
                
                tabContent.querySelector(`[class*='modal-button']`).setAttribute("data-target",`#photoModal_${profile.objectId}`)

                let photoModal = tabContent.querySelector("#photoModal_model")
                photoModal.setAttribute('id',`photoModal_${profile.objectId}`)
                photoModal.removeAttribute("style")
                
                profile.photos.forEach(photo =>{
                    let img = photoModal.querySelector("#photo_model").cloneNode({deep:true})
                    img.removeAttribute("style")
                    img.removeAttribute("id")
                    img.querySelector(`img`).setAttribute('src',photo.url)
                    img.querySelector(`img`).addEventListener("click" , (e)=>{
                        e.preventDefault()
                        let url = e.target.getAttribute("src")
                        document.querySelector(`[profileId='${profile.objectId}'][class*='photo_url']`).setAttribute("src",url)
                        $(`#photoModal_${profile.objectId}`).modal('hide')
                    })
                    photoModal.querySelector(".modal-body").append(img)
                })
                photoModal.querySelector("#photo_model").remove()
                
                profile.photos.forEach(photo=>{
                    if(photo.selected){
                        tabContent.querySelector(`#photo_checkbox_${profile.objectId}`).checked = true
                        tabContent.querySelector('img').setAttribute('src',photo.url)
                        tabContent.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).value = photo.price
                    }
                })









                if(profile.status =="running" || profile.status == "waiting"){
                    document.querySelector(`[href *='#profile_${profile.objectId}']`).innerHTML = profile.username + `<img width="9px" src="running.svg" alt="">`
                    tabContent.querySelector(`textarea`).disabled = true
                    tabContent.querySelector(`select`).disabled = true
                    tabContent.querySelector(`[class*='button-start']`).disabled = true
                    tabContent.querySelector(`[class*='button-pause']`).disabled = false
                    tabContent.querySelector(`[class*='button-stop']`).disabled = false
                    tabContent.querySelector(`#photo_checkbox_${profile.objectId}`).disabled = true
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).disabled = true
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='modal-button']`).disabled = true
                }

                if(profile.status =="paused"){
                    tabContent.querySelector(`textarea`).disabled = true
                    tabContent.querySelector(`select`).disabled = true
                    tabContent.querySelector(`[class*='button-start']`).disabled = false
                    tabContent.querySelector(`[class*='button-pause']`).disabled = true
                    tabContent.querySelector(`[class*='button-stop']`).disabled = false
                    tabContent.querySelector(`#photo_checkbox_${profile.objectId}`).disabled = true
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).disabled = true
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='modal-button']`).disabled = true
                }
                if(profile.status =="stoped" ){
                    document.querySelector(`[href *='#profile_${profile.objectId}']`).innerHTML = profile.username + `<img width="9px" src="stoped.svg" alt="">`
                    tabContent.querySelector(`textarea`).disabled = false
                    tabContent.querySelector(`select`).disabled = false
                    tabContent.querySelector(`[class*='button-start']`).disabled = true
                    tabContent.querySelector(`[class*='button-pause']`).disabled = true
                    tabContent.querySelector(`[class*='button-stop']`).disabled = true
                    tabContent.querySelector(`#photo_checkbox_${profile.objectId}`).disabled = false
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='photo-price']`).disabled = false
                    tabContent.querySelector(`[profileId='${profile.objectId}'][class*='modal-button']`).disabled = false
                }

                document.querySelector("#myTabContent").append(tabContent)

            });
            setInterval(()=>{
                chrome.runtime.sendMessage(
                    {
                        msg:"get_view"
                    },
                    function(result) {
                        if(!result){
                            return
                        }
                        console.log(result)
                        result.data.forEach(profile =>  {
                            document.querySelector(`[profileId='${profile.objectId}'][class*='msg-today']`).innerHTML = profile.msgSent
                        });
                        return
                    }
                        
    
                ) 
            },20000)
            
        }
    );
}




